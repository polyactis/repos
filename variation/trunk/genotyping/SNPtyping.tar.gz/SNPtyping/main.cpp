#include "classes.h"

struct timeval end;
struct timeval begin;
long hour, minu, sec, usec;

gsl_rng * r;









int main(int narg, char ** argc)        //first argument: argumentfile     
{
  gettimeofday(&begin, NULL);   //measures the time the program takes
  
  r = gsl_rng_alloc (gsl_rng_taus);
  int seed = time(NULL);
  cout<<"#Seed: "<<seed<<endl;
  gsl_rng_set (r, seed);

  if (narg > 1) {

    vector<vector<string> > argList = Parse_argument(narg, argc);
    for (int i = 0; i != (int) argList.size(); i++) {for (int j = 0; j != argList[i].size(); j++) cout<<argList[i][j]<<"\t"; cout<<endl;}
    TypeSNPs_commandLine(argList); 
  }
  

  if (narg == 1) {
    int phase[] = {1, 2, 3}; vector<int> phasev (phase, phase + 3); //what phase do we want to look at?
    //TestType choiceTest = basic1df; action type_again = rescore; Parse_SNPIds("data/test", 0, 1, type_again, basic1df, "temp.txt", phasev);

    //CreatePedFile("data/list_assayID_short.txt");
    //CreatePedFile("data/list_cut.txt");

  }




  //--------------------------------------------------------------------------------
  //Gestion de l'affichage du temps, ne pas s'en occuper
  gettimeofday(&end, NULL);
  usec = (end.tv_usec - begin.tv_usec + 1000000L) % (1000000L);
  sec = (end.tv_sec - begin.tv_sec);
  if (end.tv_usec < begin.tv_usec) sec--;
  minu = sec/60; sec %= 60;
  hour = minu/60; minu %= 60;
  printf("#Temps d'execution: %ih %02i' %02i.%03i''\n", (int) hour, (int) minu, (int) sec, (int) (usec/1000));
  
  return 0;
}





