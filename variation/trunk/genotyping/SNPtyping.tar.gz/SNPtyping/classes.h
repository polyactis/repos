

#ifndef _TYPCLASSES_H_
#define _TYPCLASSES_H_

#include<sys/time.h>   //old fashioned C library that has the functions to read the time

#include<vector>
#include<string>
#include<iostream>
#include<fstream>      //headers for file streaming: ifstream, ofstream
#include<iterator>       
#include<sstream>
#include<map>         //hash tables, quite useful
#include<set>         //hash tables, quite useful
#include <boost/bind.hpp>
#include<numeric>

#include<gsl/gsl_rng.h>      //random number generation
#include<math.h>      //sinh is in here


extern gsl_rng * r;
using namespace std;

enum output_mode {minimum, minimum_perturbed};
enum action {rescore, test};
enum DataStatus {good, excluded};
enum sexStatus {unknownS, male, female, both};
enum ccStatus {unknownC, healthy, disease};
enum TestType {na, basic1df, basic2df, Xinac_cases, Xinac_hetero};


typedef map<string, vector<string> > myHash;

class DataPoint
{
 private:
  DataStatus status;           //is this data point a point we want to keep, or do we want to exclude it somehow?
  
  string chipScan, sampleID, individual;
  int region;
  sexStatus sex;
  ccStatus control_case;   //basic description for the individual associatd with this data point

  vector<double> signal_ACGT;   //size 4 a-priori, the raw signal intensity  
  vector<double> f,u, pert;     //probabilities to belong to each of the clusters 
  double S, contrast, likelihood;




 public:
  friend double sumLike(double sumSoFar, const DataPoint & d);  
  DataPoint(const vector<double> & intensity, const int nclusters, const string & chipScan);

  //----------------- Data parsing utilities
  void ChipRead_to_plate(const myHash & chipread_to_plate);
  void Plate_to_individual(const myHash & plate_to_individual);
  void Info_individual(const myHash & info_individual);

  void Exclude_include(const set<string> & excluded_chipreads, const set<string> & excluded_individuals, const double sum_intensity);    //tests if this data point should be included or excluded
  void Fill_genotypes(const myHash & genotypesInfo);

  void Set_contrasts (const int a1, const int a2);   //sets the value for the contrasts
  void Pick_alleles (vector<int> & v) const; //finds what allele is the most frequent
  void MAF (vector<double> & count, const bool X) const;   //MAF
  
  void Update_phenotype (const myHash & m, const TestType choiceOfTest);


    //---------small utilities
  bool Test_cc (const ccStatus c) const  {return ( ( status == good) && (control_case == c) ) ;};
  void Count_cc (vector<double> & count) const {if (Test_cc(healthy)) {count[0]++;}  if (Test_cc(disease)) {count[1]++;}}
  bool Test_sex (const sexStatus s) const  {return ( (status == good) && (sex == s) );};
  void Set_status(const DataStatus ds) {status = ds;}
  void Set_intensity(const double a1, const double a2) {signal_ACGT.assign(4, 0.); signal_ACGT[0] = a1; signal_ACGT[1] = a2;}
  void Set_region(const int reg) {region = reg;}
  double Perturbate (const int allele1, const int allele2, const double sigma1, const double sigma2);    //modifies the contrast only, not the intensity
  double Get_signal (const int allele, const int what_call);

  //---------for the EM algorithm
  double Expectation (const vector<vector<double> > & lambda, const vector<double> & mean, const vector<double> & stdev, const vector<double> & nu, const int nclusters, vector<double> & tvec, const bool forPerturb);
  void EstimateLambda (vector<vector<double> > & alpha, const double weight);
  void Update_mean(vector<double> & values, const int cluster);
  void Update_sigma(vector<double> & values, const int cluster, const double mean);
  void Update_nu(vector<double> & values, const int cluster);

  void Test ( vector<vector<vector<double> > > & controls,  vector<vector<vector<double> > > & cases , const bool X, const int nregions) const;
  void Print(ostream & out, const int mod, const int phase, const int a1, const int a2) const;

  void Empirical_distribution (vector<double * > & stats, vector<int> & counter);



  
};




class SNP 
{
 private:
  int nclusters, nregions;   //how many regions, and how many clusters in the data?  
  int phase, location, allele1, allele2;
  string SNPID, marker, chromosome, annotation;      //names for this SNP: one technical (SNPID), one is more user-friendly (rsnumber)
  sexStatus sex;
  
  vector<DataPoint> data;  

  //-----------------  parameters for the clustering procedure
  vector<vector<double> > lambda;     //background frequencies, one set of values per region
  vector<double> mean, stdev, nu;      //parameters for the clustering procedure
  vector<vector<double> > boundaries;
  vector<double> empirical_mean, empirical_stdev, empirical_lambda;   //empirical values of the parameters, useful to compute the quality score
  double logLikelihood;
  






 public:  
  friend vector<int> Pick_alleles(const vector<SNP * > & ar);  //finds what the two alleles are using the intensity information
  friend void Fill_SNP (SNP * mySNP, const string & data);   //takes a row from Hin-Tak's files and fill the SNP class with it


  void ChipRead_to_plate( const myHash & m ) {for_each (data.begin(), data.end(), boost::bind (&DataPoint::ChipRead_to_plate, _1, boost::ref(m) ));};
  void Plate_to_individual( const myHash & m ) {for_each (data.begin(), data.end(), boost::bind (&DataPoint::Plate_to_individual, _1, boost::ref(m) ));};
  void Info_individual( const myHash & m ) {for_each (data.begin(), data.end(), boost::bind (&DataPoint::Info_individual, _1, boost::ref(m) ));};
  void Info_assay( const myHash & m );
  void Update_phenotype (const myHash & m, const TestType choiceOfTest) {for_each(data.begin(), data.end(), boost::bind(&DataPoint::Update_phenotype, _1, boost::ref(m), choiceOfTest));};

  void Fill_genotypes(const myHash & genotypesInfo) {for_each(data.begin(), data.end(), bind(&DataPoint::Fill_genotypes, _1, boost::ref(genotypesInfo)));}  //fills a SNP class with genotype info ;
  void Exclude_include( const set<string> & excluded_chipreads, const set<string> & excluded_individuals, const double sum_intensity );    //tests if this data point should be included or excluded
  void Set_contrasts (const int a1, const int a2)  {for_each(data.begin(), data.end(), boost::bind(&DataPoint::Set_contrasts, _1, a1, a2)); allele1 = a1; allele2 = a2;}; //sets the value for the contrasts


  //-------------------EM related stuff
  friend void Update_lambda(vector<SNP *> & vdata, const bool HWloc);
  void Update_mean();
  void Apply_boundaries_mean();
  void Update_sigma();
  void Update_nu();
  double Expectation ();
  void Init_parameters (const int number, const double initial_p = 0.9); //initialise the value of the parameters
  double LogLikelihood() const;      //compute the likelihood of the vector DataPoint given the current value of the parameters
  void Perturbate();

  //------------------ basic constructors
  SNP (const int nclusters, const int nregions, const int phase, const string & SNPID);
  SNP * LimitedCopy () const;        //copy everything but not the data points
  void InsertDataPoint(const DataPoint & d);
  vector<SNP *> Split_by_sex() const;
  vector<SNP *> Split_by_cc()  const;
  void Print (ostream & out, const int start, const int end, const int mode) const;         //outputs the data in a file

    
  //----------- basic functions
  int nregionsf() const  {return nregions;};
  int locationf() const  {return location;};
  int nclustersf() const {return nclusters;};
  int nbDataPoints() const  {return data.size();}
  string annotationf() const  {return annotation;};
  string markerf() const {return marker;};
  string SNPIDf() const  {return SNPID;};
  string chromosomef() const  {return chromosome;}
  bool Test_sex(const sexStatus s) const  {if (sex == s) {return true;} else {return false;}};
  bool ChrX() const  {if (chromosome == "X") {return true;} else {return false;}};
  void Test ( vector<vector<vector<double> > > & controls,  vector<vector<vector<double> > > & cases , const bool X) const;


  //------------extra stuff
  void Empirical_distribution ();
  double Exclude_poor_sets (const double threshold);
  double Confidence_in_calls() const;   
  void MAF(vector<double> & count) const;
  void Count_cc (vector<double> & count) const {for_each (data.begin(), data.end(), boost::bind(&DataPoint::Count_cc, _1, boost::ref(count)));}
};



template <class T>   std::string toString( T value )  { std::ostringstream oss;   oss.precision(3);  oss << value;  return oss.str();}


//util.cpp
void Print_header_output_file(const int mode, ostream & out);   //prints the header line of the output files
myHash GetHash (const char * inputfile, const int index, const vector<int> & columns);
vector<SNP *> Split (const vector<SNP *> & v, const int sex_or_cc );
vector<int> ReadIntList(const char * nlist);   //reads into a vector of integers
set<string> Parse_list(const char * nlist);
double MAF (const vector<SNP *> & v);

//parse.cpp
vector<SNP *> Parse_ParAllele (const int SNPid, const vector<int> & phase);
void Parse_HinTak(const set<string> & SNPName, const vector<string> & file, const string & outputfolder, const output_mode mode);    //--- parser for HinTak's normalization program's output: I provide the set of strings I want to parse as well as the location of the file of interest
vector<vector<string> > Parse_argument (const int narg, char ** argc);
void TypeSNPs_commandLine(const vector<vector<string> > & commandLine);

//EM.cpp
void EM (vector<SNP *> & v, const vector<int> & initial_conditions);    //the actual EM algorithm
void Perturbate (vector<SNP *> vs, const int nb_random);


//constructor.cpp
vector<int> Pick_alleles(const vector<SNP * > & ar);

//test.cpp
string Test (const vector<SNP *> & v, const TestType myTest);

//final.cpp
void Update_phenotype(vector <SNP *> & v, const myHash & m, const TestType choiceOfTest);
void Parse_SNPIds (const char * list_SNPs, const int start, const int jump, const action whatToDo, const TestType choiceOfTest, const char * resultFile, const vector<int> & phasev);
void CreatePedFile(const char * list_SNPs);



//parAllele.cpp
void TestSNPs (const vector<int> & IDlist, const vector<int> & phasev, const action whatToDo, const TestType choiceOfTest, const string & folder, ostream & out);


#endif
