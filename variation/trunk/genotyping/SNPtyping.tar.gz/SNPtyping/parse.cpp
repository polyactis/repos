#include "classes.h"
#include <zlib.h>






void TypeSNPs_commandLine(const vector<vector<string> > & commandLine) 
{

  output_mode mode = minimum;   
  vector<string> fileNames;
  set<string> SNPList;
  string outputFolder ("defaultNoFolder");


  for (int i = 0; i != (int) commandLine.size(); i++) {
    if (commandLine[i][0] == "-i") {                                                               //--------------- list of files
      for (int j = 1; j != (int) commandLine[i].size(); j++) {fileNames.push_back (commandLine[i][j]);}
    }

    if ( (commandLine[i][0] == "-snps") && (commandLine[i].size() == 2) ) {SNPList = Parse_list(commandLine[i][1].c_str());}     //---------------------------- list of SNPs: version where one reads one file

    if (commandLine[i][0] == "-o") {outputFolder.assign(commandLine[i][1]);}    //------------------------ the output folder

    if (commandLine[i][0] == "-perturbations") {cout<<"Using the perturbation mode\n"; mode = minimum_perturbed;}    //------------------------ the output folder

    if (commandLine[i][0] == "-platform") {
      cout<<"Using the platform: "<<commandLine[i][1]<<endl;    //------------------------ the output folder
      if (commandLine[i][1] != "Affy") {cerr<<"Unrecognized platform\n"; exit(1);}
    }
  }
  
  Parse_HinTak(SNPList, fileNames, outputFolder, mode);        
}



vector<vector<string> > Parse_argument (const int narg, char ** argc) 
{
  vector<vector<string> > temp;
  vector<string> loc;      

  int count = 1;
  while ( count < narg ) {    
    loc.push_back(argc[count]);
    count++;
    if (count == narg) {temp.push_back(loc);break;}
    else {if (argc[count][0] == '-') {temp.push_back(loc);loc.assign(0, "nothing");}}
  }
    
  return temp;  
}










SNP * Parse_header(const char * buffer, const int cohort) {   //takes a header from Hin-Tak's files and create a SNP class that will contain the data

  string SNPID("generic");
  int nclusters = 3, nregions = 1;
  SNP * res = new SNP(nclusters, nregions, cohort, SNPID);
  vector<double> intensity(4, -1.);


  string line (buffer);
  istringstream instream;
  instream.clear(); instream.str(line);

  string junk, indA, indB;
  for (int i = 0; i != 5; i++) {instream>>junk;} //some ninteresting headers
  while (!instream.eof()) {
    instream>>indA; instream>>indB;
    DataPoint * d = new DataPoint(intensity, nclusters, indA);    //here the data point is created and inserted in the SNP class
    d->Set_region(0);
    res->InsertDataPoint (*d);    
  }

  return res;
}






void Fill_SNP (SNP * mySNP, const string & data)   //takes a row from Hin-Tak's files and fill the SNP class with it
{
  istringstream instream;
  instream.clear(); instream.str(data);  
  double a1, a2;

  string junk; for (int i = 0; i != 5; i++) {instream>>junk;} //some uninteresting headers, let us skip them

  int count = 0;
  for (int i = 0; i != (int) mySNP->data.size(); i++) {   //now for each individual and each allele we parse the data
    instream>> a1; instream >> a2; 
    (mySNP->data)[count].Set_intensity(a1, a2);   //sets the intensities
    mySNP->allele1 = 0;
    mySNP->allele2 = 1;
    count++;
  }
  
  mySNP->Set_contrasts(mySNP->allele1, mySNP->allele2);  //computes the contrast using the intensity we just obtained
}




void Parse_HinTak(const set<string> & SNPName, const vector<string> & file, const string & outputFolder, const output_mode mode)    //--- parser for HinTak's normalization program's output: I provide the set of strings I want to parse as well as the location of the file of interest
{

  if (outputFolder == "defaultNoFolder") {cerr<<"Error. The output folder has not been specified. You have to specify an output folder\n"; exit(1);}




  string assayID, rsID, location;
  istringstream instream;

  int maxline = 1000000;
  char * buf = new char[maxline];
  
  int nCohorts = file.size();
  vector<gzFile> vec_pointers (nCohorts);
  vector<string> vec_data(nCohorts);

  vector<SNP *> data;

  
  cout<<"Nb of cohorts being considered: "<<nCohorts<<endl;
  for (int cohort = 0; cohort != nCohorts; cohort++) {
    vec_pointers[cohort] = gzopen(file[cohort].c_str(), "rb");   //opens the files that hold the data
    gzgets(vec_pointers[cohort], buf, maxline);         //puts the header line in the buffer
    data.push_back(Parse_header(buf, cohort));         //now parse the header line to create the SNP of interest
  }


  
  int count = 0, flag = 0;
  while (1) {  //now look at all the files and parse the data
    vector<string> rsIDfound, assayIDfound;
    count++;

    for (int cohort = 0; cohort != nCohorts; cohort++) {   //for each cohort, read a line
      gzgets(vec_pointers[cohort], buf, maxline);
      if (gzeof(vec_pointers[cohort])) {flag = 1; break;}
	  
      vec_data[cohort].assign(buf);
      instream.clear(); instream.str(vec_data[cohort]);	  
      instream >> assayID; instream >> rsID; instream >> location; 
      assayIDfound.push_back(assayID); rsIDfound.push_back(rsID);
    }
    if (flag == 1) {break;}   //if we are done, skip this part

      
    
    for (int j = 1; j < nCohorts; j++) {if (assayIDfound[j] != assayIDfound[0]) {cerr<<"The ordering of the SNPs in the various cohort files seem to differ. This is not allowed in that code."<<endl; exit(1);}}
    
    if ( (SNPName.count(assayIDfound[0]) == 1)  || (SNPName.count(rsIDfound[0]) == 1) || SNPName.empty() ) {
      cout<<"Now typing SNP: "<<assayIDfound[0]<<"-"<<rsIDfound[0]<<endl;

      for (int cohort = 0; cohort != nCohorts; cohort++) {Fill_SNP(data[cohort], vec_data[cohort]);}   //for each cohort, read the line and place the data in a class that will be used for typing

      int conditions[] = {5, 6, 7, 8, 9, 10}; vector<int> vcond (conditions, conditions+6);   //set of initial conditions I want to use
      EM(data, vcond);                      //------------  Now we can actually type the data: this runs the EM algorithm

      if (mode == minimum_perturbed) {Perturbate(data, 10);  for_each(data.begin(), data.end(), boost::bind(&SNP::Set_contrasts, _1, 0, 1));}  //computes the contrast using the intensity we just obtained then put it back to the normal value


      string name ("unknown");
      if (SNPName.count(assayIDfound[0]) == 1)   {name.assign(assayIDfound[0]);}
      if (SNPName.count(rsIDfound[0]) == 1)      {name.assign(rsIDfound[0]);}
      if (SNPName.empty()) {if (rsIDfound[0] != "---") {name.assign(rsIDfound[0]);} else {name.assign(assayIDfound[0]);}}

      
      string fullName (outputFolder + "/" + name + ".gen");        //------------------------- Now that the clustering is done, here is the printing part
      cout<<"Printing results in "<<fullName<<endl;
      ofstream out (fullName.c_str());
      if (!out.is_open()) {cerr<<"Error: cannot open the output file: "<<fullName<<endl; cerr<<"Have you checked that this folder exists?\n";exit(1);}      
      Print_header_output_file(mode, out);    //prints the header line
      for_each(data.begin(), data.end(), boost::bind(&SNP::Print, _1, boost::ref(out), mode, INT_MAX, mode));   //prints one line per SNP
      out.close();
    } 
        
    if (count % 1000 == 0) {cout<<"Just finished SNP number "<<count<<" in the large intensity file\n";}
  }
}



vector<int> assay_ID_list (const int nfiles)
{
  vector<int> IDlist = ReadIntList ("data/list_assayID.txt");    //-------------------------- reads the list of SNP IDs in the vector IDlist

  int jump = IDlist.size()/nfiles;  
  vector<int> breaks;  
  for (int i = 0; i != nfiles; i++) {breaks.push_back(IDlist[i*jump]);} 
  breaks.push_back(INT_MAX);

  //copy (breaks.begin(), breaks.end(), ostream_iterator<int>(cout, "\n")); //to print
  
  return breaks;
}

int FileNumber(const int assay_ID, const vector<int> & breaks)       {int n = 0; while (breaks[n+1] < assay_ID) n++; return n;}




vector<SNP *> Parse_ParAllele (const int SNPid, const vector<int> & phase)
{
  vector<SNP *> res;
  int nclusters = 3, nregions = 21;

  for (int i = 0; i != (int) phase.size(); i++) { //for each phase
    int nfiles = 100; 
    vector<int> breaks = assay_ID_list (nfiles);
    
    int file = FileNumber (SNPid, breaks);
    string input_file ("/home/vplagnol/Data/Parallele/p"+ toString(phase[i]) + "cc_signals_by_assay/signals" + toString(file));
    
    cout<<"Opening file: "<<input_file<<endl;
    ifstream inp (input_file.c_str());
    if (!(inp)) {cerr<<"Cannot open the file: "<<input_file<<endl;exit(1);}
        
    SNP * nSNP = new SNP(nclusters, nregions, phase[i], toString(SNPid));      //----------------------------------------------- now we parse the file and create the class

    istringstream instream;
    string sampleID, lSNPid, s;
    vector<double> intensity(4);

    do {  
      getline(inp, s);
      instream.clear(); instream.str(s);
      instream >> sampleID;  instream >> lSNPid;
      
      if (atoi(lSNPid.c_str()) == SNPid) {
	for (int j = 0; j != 4; j++) {instream>>intensity[j];}
	DataPoint * d = new DataPoint(intensity, nclusters, sampleID);    //here the data point is created and inserted in the SNP class
	nSNP->InsertDataPoint (*d);
	delete d;
      }
    }  while (!inp.eof());  //each new line in the input file is a potential data point

    inp.close();

    res.push_back(nSNP);
  }

  return res;
}


void SNP::Exclude_include(const set<string> & exExp, const set<string> & exIndiv, const double sum_intens) 
{for_each (data.begin(), data.end(), boost::bind (&DataPoint::Exclude_include, _1, boost::ref(exExp), boost::ref(exIndiv), sum_intens));}


void SNP::Info_assay(const myHash & m)
{
  if (m.count(SNPID) == 1) {
    marker = (*m.find(SNPID)).second[0];
    location = atoi(  ((*m.find(SNPID)).second[1]).c_str() );
    annotation = (*m.find(SNPID)).second[2];
    chromosome = (*m.find(SNPID)).second[3];
    
  }
}

void DataPoint::ChipRead_to_plate  (const myHash & m)  {if (m.count(chipScan) == 1) {sampleID   = (*m.find(chipScan)).second[0];}} //------  exp to plate  (a)4003102-05634 to SMP2_0000713_E12
void DataPoint::Plate_to_individual(const myHash & m)  {if (m.count(sampleID) == 1) {individual = (*m.find(sampleID)).second[0];}}   //-------------- plate to individual


void DataPoint::Info_individual(const myHash & m)  {
  if (m.count(individual) == 1) {
    vector<string> data = (*m.find(individual)).second;
    
    if (data[0] == "1") {control_case = healthy;}   //disease status
    if (data[0] == "2") {control_case = disease;}
    
    if (data[1] == "1") {sex = male;}   //sex
    if (data[1] == "2") {sex = female;}

    region = atoi(data[2].c_str());          //region
  }
}


void DataPoint::Exclude_include(const set<string> & exExp, const set<string> & exInd, const double sum_intensity)   {
  if ( (region > 0) && (region < 21) && (exExp.count(chipScan) == 0) && (exInd.count(individual) == 0) && (individual != "unknown") && ( S > sum_intensity) ) {status = good;}  else {status = excluded;}
}




