#include "classes.h"


void SNP::InsertDataPoint(const DataPoint & d) {data.push_back(d);}


SNP::SNP(const int nclusters_a, const int nregions_a, const int phase_a, const string & SNPID_a) : nclusters(nclusters_a), nregions(nregions_a), phase (phase_a), SNPID(SNPID_a)
{
  for (int i = 0; i != nregions; i++) {lambda.push_back(vector<double> (nclusters));}     //some space for the background frequencies
  for (int i = 0; i != nclusters; i++)  {boundaries.push_back(vector<double> (2));}

  mean.assign(nclusters, -99);
  stdev.assign(nclusters, -99);
  nu.assign(nclusters, -99);
  empirical_lambda.assign(nclusters, -99);
  empirical_mean.assign(nclusters, -99);
  empirical_stdev.assign(nclusters, -99);
  sex = both;

      
}


SNP * SNP::LimitedCopy() const
{
  SNP * result = new SNP (nclusters, nregions, phase, SNPID);  

  result->chromosome = chromosome;
  result->marker = marker;
  result->location = location;
  result->annotation = annotation;

  result->lambda =  lambda; 
  result->mean = mean;
  result->nu = nu;
  result->stdev = stdev;
  result->boundaries = boundaries;

  result->empirical_lambda = empirical_lambda;  
  result->empirical_mean = empirical_mean;
  result->empirical_stdev = empirical_stdev;

  result->allele1 = allele1;
  result->allele2 = allele2;

  return result;
}




DataPoint::DataPoint (const vector<double> & signal_ACGT_a, const int nclusters, const string & chipScan_a) : chipScan(chipScan_a), signal_ACGT(signal_ACGT_a)
{
  f.assign(nclusters, -99);
  u.assign(nclusters, -99);
  pert.assign(nclusters, 0);   //paerturbation vector, initialized to zero

  status= good;
  sex = unknownS;
  control_case  = unknownC;
  region = -99;  
  S = -99.;
  sampleID.assign("unknown");
  individual.assign("unknown");

}





void DataPoint::Pick_alleles(vector<int> & v) const { if (status == good) {v [  max_element(signal_ACGT.begin(), signal_ACGT.end()) -  signal_ACGT.begin() ]++;}}


vector<int> Pick_alleles(const vector<SNP * > & ar)
{

  vector<int> alleles(4,0);
  for (int i = 0; i != (int) ar.size(); i++) {for_each (ar[i]->data.begin(), ar[i]->data.end(), boost::bind(&DataPoint::Pick_alleles, _1, boost::ref(alleles)));}  //the boost::ref is critical here (pass by reference!)

  cout<<"Alleles: "<<alleles[0]<<"\t"<<alleles[1]<<"\t"<<alleles[2]<<"\t"<<alleles[3]<<endl;

  vector<int> res(2,-99);    
  res[0] = max_element (alleles.begin(), alleles.end()) - alleles.begin();   //res[0] should be the common allele
  alleles[  res[0]  ] = -1;  //-1 is important here in case the major allele dominates for all individuals
  res[1] = max_element (alleles.begin(), alleles.end()) - alleles.begin();      

  return res;
}

