#include "classes.h"
#include <gsl/gsl_statistics_double.h>

//----------------------------------------------------------------------------------------------------  routines to split the data

// here is a fancy implementation of the surprisingly missing copy_if. Taken directly from Scott Meyer's 50 tips
template <typename InputIterator, typename OutputIterator, typename Predicate> OutputIterator copy_if(InputIterator begin, InputIterator end, OutputIterator destBegin, Predicate p)
{while (begin != end) {if (p(*begin)) *destBegin++ = *begin; ++begin;} return destBegin;}



//to read a list of integers from a file
vector<int> ReadIntList(const char * nlist)
{
  vector<int> IDlist; 
  ifstream inp (nlist);
  if (!inp) {cerr<<"Cannot open "<<nlist<<endl; exit(1);}
  istream_iterator<int>  start (inp), end;
  back_insert_iterator<vector<int> > dest (IDlist);
  copy (start, end, dest);
  inp.close();

  return IDlist;
}



vector<SNP *> SNP::Split_by_sex () const    //split by sex
{
  vector<SNP *> result;  
  SNP * ma = this->LimitedCopy(); ma->sex =  male; copy_if(data.begin(), data.end(),  back_inserter(ma->data), boost::bind(&DataPoint::Test_sex, _1, male));  //my own implementation of copy_if
  SNP * fe = this->LimitedCopy(); ma->sex = female;copy_if(data.begin(), data.end(),  back_inserter(fe->data), boost::bind(&DataPoint::Test_sex, _1, female));    //my own implementation of copy_if

  ma->sex = male; fe->sex = female;
  result.push_back(ma); result.push_back(fe);

  return result;
}


vector<SNP *> SNP::Split_by_cc () const  //split by case contol status
{
  vector<SNP *> result;  
  SNP * controls = this->LimitedCopy();    copy_if(data.begin(), data.end(),  back_inserter(controls->data), boost::bind(&DataPoint::Test_cc, _1, healthy));  //my own implementation of copy_if
  SNP * cases = this->LimitedCopy();    copy_if(data.begin(), data.end(),  back_inserter(cases->data), boost::bind(&DataPoint::Test_cc, _1, disease));     //my own implementation of copy_if
  result.push_back(controls); result.push_back(cases);
  return result;
}



vector<SNP *> Split (const vector<SNP *> & v, const int sex_or_cc )
{
  vector<SNP *> result;
  
  for (int i = 0; i != (int) v.size(); i++) {
    vector<SNP *> extra;
    if (sex_or_cc == 0) {extra = v[i]->Split_by_sex();}
    if (sex_or_cc == 1) {extra = v[i]->Split_by_cc();}
    result.insert(result.end(), extra.begin(), extra.end());
  }
  
  return result;
}



//------------------------------------------------------------------------------------- routines to find the alleles and compute contrasts

void DataPoint::Set_contrasts (const int a1, const int a2)
{
  double S1 = signal_ACGT[a1], S2 = signal_ACGT[a2];
  S = S1 + S2;
  if (S == 0.)  {contrast = 0.;} 
  else {
    double y = (2*S2/S) - 1.; 
    if (fabs(y) <  1) {contrast = sinh(2*y)/sinh(2.);}
    if (fabs(y) >= 1) {contrast = y;}
  }  
}









myHash GetHash (const char * inputfile, const int index, const vector<int> & columns)
{
  ifstream inp (inputfile);
  if (!(inp)) {cerr<<"Cannot open file "<<inputfile<<endl; exit(1);}  
  
  vector <string> vtemp (columns.size());
  string temp, ind, s;
  istringstream instream;

  myHash my_hash;
  while (getline(inp, s)) {  
    instream.clear(); instream.str(s); 
    
    int mcol = 0, col = 0;
    while (col < (int) columns.size()) {
      instream >> temp;
      if (mcol == index)  {ind = temp;}
      if (columns[col] == mcol) {vtemp[col] = temp;col++;}
      mcol++;
    }
    my_hash.insert (pair<string, vector<string> > (ind, vtemp));
  }  

  return my_hash;
}




void DataPoint::Print (ostream & out, const int mode, const int phase, const int a1, const int a2) const       //different versions should be available for printing
{

  if (mode == minimum) {
    out<<chipScan<<"\t"<<phase<<"\t";    
    out<<signal_ACGT[a1]<<"\t"<<signal_ACGT[a2]<<"\t"<<contrast<<"\t";    
    out<<max_element(f.begin(), f.end()) - f.begin()<<"\t"; //meant to output the typing information
    copy (f.begin(), f.end(), ostream_iterator<double>(out, "\t"));
    out<<endl;
  }

 if (mode == minimum_perturbed) {
    out<<chipScan<<"\t"<<phase<<"\t";    
    out<<signal_ACGT[a1]<<"\t"<<signal_ACGT[a2]<<"\t"<<contrast<<"\t";    
    out<<max_element(f.begin(), f.end()) - f.begin()<<"\t"; //meant to output the typing information
    copy (f.begin(), f.end(), ostream_iterator<double>(out, "\t"));
    
    double sum = accumulate(pert.begin(), pert.end(), 0.);
    for (int i = 0; i != (int) pert.size(); i++) {out<<pert[i]/sum<<"\t";}   //need to make it better, more std style

    out<<endl;
  }




  //if (mode == 0) {out<<chipScan<<"\t"<<sampleID<<"\t"<<individual<<"\t"<<control_case<<"\t"<<sex<<"\t"<<region<<endl;}
  //  out<<status<<endl;
  //}

}




void Print_header_output_file(const int mode, ostream & out)   //prints the header line of the output files
{  
  switch (mode) {
  case minimum: {out<<"chipScan\tphase\tS1\tS2\tcontrast\tcall\tP1\tP2\tP3\n";break;}
  case minimum_perturbed: {out<<"chipScan\tphase\tS1\tS2\tcontrast\tcall\tP1\tP2\tP3\tP1_perturbed\tP2_perturbed\tP3_perturbed\n";break;}
  default: {cerr<<"This output mode has not been specified\n"; exit(1);}
  }
}



void SNP::Print (ostream & out, const int start, const int end, const int mode) const  {
  if (mode >= 0) {
    if (start > end) {cerr<<"Illegal printing\n"; exit(1);}
    for (int i = max((int) start, 0); i != min((int) data.size(), end); i++) {data[i].Print(out, mode, phase, allele1, allele2);}
  }

  if (mode == -1) {
    cout<<"\nParameters:\n";
    cout<<"Mean:\t"<<mean[0]<<"\t"<<mean[1]<<"\t"<<mean[2]<<"\t"<<endl;
    cout<<"Sigma:\t"<<stdev[0]<<"\t"<<stdev[1]<<"\t"<<stdev[2]<<"\t"<<endl;
    cout<<"Nu:\t"<<nu[0]<<"\t"<<nu[1]<<"\t"<<nu[2]<<"\t"<<endl;
    for (int i = 0; i != nregions; i++) cout<<"Region "<<i<<": "<<lambda[i][0]<<"\t"<<lambda[i][1]<<"\t"<<lambda[i][2]<<endl;
  }



}



set<string> Parse_list(const char * name) 
{
  set<string> li;
  string temp;

  ifstream inp (name);
  if (!inp) {cerr<<"Cannot open "<<name<<endl; exit(1);}
  while (!inp.eof()) {inp >> temp; if (inp.eof()) break; li.insert(temp);}
  inp.close();

  return li;
}


void DataPoint::Fill_genotypes(const myHash & genotypesInfo) 
{
  status = excluded;
  if (genotypesInfo.count(chipScan) == 1) {
    vector<string> proba = (*genotypesInfo.find(chipScan)).second;
    double t = 0.; for (int i = 0; i != (int) proba.size(); i++)   {f[i] = atof(proba[i].c_str()); t += f[i];}
    if ( fabs(t-1.) < 0.001) {status = good;}
  }      
}






void DataPoint::MAF (vector<double> & count, const bool X) const 
{
  if (status == good) {
    int best = max_element(f.begin(), f.end()) - f.begin();
    if ( (sex == male  ) && (X == true) )   { //if there is only one copy of the chromosome
      if (best == 0) {count[0]++; }
      if (best == 1) {cerr<<"One cannot have heterozygous males on the X "<<f[0]<<"  "<<f[1]<<"  "<<f[2]<<endl; exit(1);}
      if (best == 2) {count[1]++;}
    }    
    else  {  //here we have two copies of the chromosome
      if (best == 0) {count[0] += 2;}
      if (best == 1) {count[0]++;count[1]++;}
      if (best == 2) {count[1] += 2;}
    }
  }
}


void SNP::MAF(vector<double> & count) const {bool X = this->ChrX(); for_each (data.begin(), data.end(), boost::bind(&DataPoint::MAF, _1, boost::ref(count), X));}


double MAF (const vector<SNP *> & v) 
{
  vector<double> count(2, 0.);
  for_each(v.begin(), v.end(), boost::bind(&SNP::MAF, _1, boost::ref(count)));
  return (count[1]/max((count[0]+count[1]), 1.));
}






double SNP::Exclude_poor_sets (const double threshold)
{
  double QC = this->Confidence_in_calls();
  if (QC < threshold) {for_each(data.begin(), data.end(), boost::bind(&DataPoint::Set_status, _1, excluded));QC = 100;}
  return QC;
}







void DataPoint::Empirical_distribution (vector<double * > & stats, vector<int> & counter)
{  
  if (status == good) {
    int call = max_element (f.begin(), f.end()) - f.begin();
    stats[call][ counter[call] ] = contrast;
    counter[call]++;
  }
}


void SNP::Empirical_distribution ()
{
  vector<double *> stats; for (int i = 0; i != nclusters; i++)   {stats.push_back(new double [data.size()]);}
  vector<int> counter(nclusters, 0);
  
  for_each (data.begin(), data.end(), boost::bind(&DataPoint::Empirical_distribution, _1, boost::ref(stats), boost::ref(counter)));

  double n = (double) accumulate(counter.begin(), counter.end(), 0);

  if (n > 0) {
    for (int i = 0; i != nclusters; i++) {

      if (counter[i] > 0) {empirical_lambda[i] = counter[i]/n;}

      if (counter[i] > 1) {
	empirical_mean[i] = gsl_stats_mean(stats[i], 1, counter[i]);
	empirical_stdev[i] = gsl_stats_sd(stats[i], 1, counter[i]);
      }
    }  
  }
  
  for (int i = 0; i != nclusters; i++)   delete [] stats[i];  
}




double SNP::Confidence_in_calls() const 
{  
  double lconfidence = 100.;             //value for the monomorphic SNPs
  bool mono = true;
  for (int i = 0; i != nclusters; i++) {
    for (int j = i+1; j < nclusters; j++) {
      if ( (empirical_mean[i] !=  -99) && (empirical_mean[j] != -99) )   {lconfidence = min( lconfidence, fabs((empirical_mean[i] - empirical_mean[j]))/( empirical_stdev[i] + empirical_stdev[j] ));mono = false;}
    }
  }

  if (mono == true) lconfidence = 0.;
  return lconfidence;
}


