#include "classes.h"
#include <gsl/gsl_randist.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf_psi.h>
#include <gsl/gsl_statistics_double.h>



void SNP::Init_parameters(const int number, const double initial_p)     //initial conditions for the EM algorithm
{
  double p = initial_p;

  //------------------------------------------------ firstset the boundaries right
  if ( (number >= 0) && (number <= 4) ) {
    nclusters = 3;
    boundaries[0][0] = -1.1;   boundaries[0][1] = -0.5;
    boundaries[1][0] = -0.5, boundaries[1][1] = 0.5;
    boundaries[2][0] = 0.5;  boundaries[2][1] = 1.1;    
    nu[0] = 4.; nu[1] = 4.; nu[2] = 4.;
    
  }


  if ( (number >= 5) && (number <= 10) ) {
    nclusters = 3;
    boundaries[0][0] = -1;   boundaries[0][0] = -0.3;
    boundaries[1][0] = -0.3, boundaries[1][1] = 0.3;
    boundaries[2][0] = 0.3;  boundaries[2][1] = 1.;
    nu[0] = 4.; nu[1] = 4.; nu[2] = 4.;
  }
  

  switch (number) {
    
  case 0: {  
    mean[0] = -0.9;mean[1] = 0.;mean[2] = 0.9;
    stdev[0] = 0.1; stdev[1] =  0.1; stdev[2] = 0.1;
    break;
  }
  case 1: {
    mean[0] = -0.9;mean[1] = 0.; mean[2] = 0.9;
    stdev[0] = 0.03;stdev[1] = 0.03;stdev[2] = 0.03;
    break;
  }
  case 2: {        //important, the one with 1 cluster
    p = 1.;
    mean[0] = 0.; mean[1] = 0; mean[2] =  0;
    stdev[0] = 0.3; stdev[1] =  0.3; stdev[2] = 0.3;
    break;
  }
  case 3: {           //shifted to the right
    boundaries[0][0] = -1.1;  boundaries[0][1] = -0.2;
    boundaries[1][0] = -0.2; boundaries[1][1] = 0.7;
    boundaries[2][0] = 0.7;  boundaries[2][1] = 1.1;
    mean[0] = -0.9; mean[1] = 0.25; mean[2] = 0.9;
    stdev[0] = 0.1; stdev[1] = 0.1; stdev[2] = 0.1;
    break;
  }
  case 4: {          //shifted to the left
    boundaries[0][0] = -1.1;  boundaries[0][0] = -0.7;
    boundaries[1][0] = -0.7; boundaries[1][1] = 0.2;
    boundaries[2][0] = 0.2;  boundaries[2][2] = 1.1;
    mean[0] = -1.; mean[1] = -0.25; mean[2] = 1.;
    stdev[0] = 0.1; stdev[1] = 0.1; stdev[2] = 0.1;
    break;
  }
    
    //--------------from here these conditions were used for the WTCCC
  case 5: {  
    mean[0] = -0.5;mean[1] = 0.;mean[2] = 0.5;
    stdev[0] = 0.03;stdev[1] = 0.03;stdev[2] = 0.03;
    break;
  }  
  case 6: {
    mean[0] = -0.5;mean[1] = 0.;mean[2] = 0.5;
    stdev[0] = 0.01;stdev[1] = 0.01;stdev[2] = 0.01;
    break;
  }    
  case 7: {
    mean[0] = -1.; mean[1] = 0.; mean[2] =  1.;
    stdev[0] = 0.1; stdev[1] =  0.1; stdev[2] = 0.1;
    break;
  }
  case 8: {        //important, the one with 1 cluster
    p = 1.;
    mean[0] = 0.; mean[1] = 0; mean[2] =  0;
    stdev[0] = 0.1; stdev[1] =  0.1; stdev[2] = 0.1;
    break;
  }  
  case 9: {          //initial condition for shifted cloud to the right
    boundaries[0][0] = -1.; boundaries[0][1] = 0.;
    boundaries[1][0] = 0.;  boundaries[1][1] = 0.5;
    boundaries[2][0] = 0.5; boundaries[2][1] = 1.5;
    mean[0] = -0.6; mean[1] = 0.2; mean[2] = 0.6;
    stdev[0] = 0.1; stdev[1] = 0.05; stdev[2] = 0.1;
    break;
  }  
  case 10: {  //initial condition for shifted cloud to the left
    boundaries[0][0] = -1.5;  boundaries[0][1] = -0.8;
    boundaries[1][0] = -0.45; boundaries[1][1] = 0.;
    boundaries[2][0] = 0.;    boundaries[2][1] = 1.;
    mean[0] = -0.8; mean[1] = -0.2; mean[2] = 0.5;
    stdev[0] = 0.1; stdev[1] = 0.1; stdev[2] = 0.1;
    nu[0] = 2;
    break;
  }
    
  default: {cerr<<"Unknown number "<<number<<endl;exit(1);}
  }
  
  
  //----------------- Normalize lambda
  vector<double> tlambda (nclusters, -1.);
  if ((int) lambda.size() < nregions) {cout<<"The 2-dimensional array lambda is too small\n";exit(1);}

  for (int r = 0 ; r != nregions; r++) {
    if (sex == male) {lambda[r][0]=p;lambda[r][1]=0.;lambda[r][2] = 1.-p;}  //male frequencies
    else {lambda[r][0] = p*p; lambda[r][1] = 2.*p*(1.-p); lambda[r][2] = (1.- p)*(1.- p);}  //female frequencies
    
    double t = accumulate (lambda[r].begin(), lambda[r].end(), 0.);
    for (int i = 0; i != nclusters; i++) lambda[r][i] /= t;
  }
}



double my_t_pdf( const double x, const double nu, const double sigma, const double m)  {return (gsl_ran_tdist_pdf ((x - m)/sigma, nu)/sigma);}



//the following routine sets f and u
double DataPoint::Expectation (const vector<vector<double> > & lambda, const vector<double> & mean, const vector<double> & stdev, const vector<double> & nu, const int nclusters, vector<double> & tvec, const bool forPerturb) //tvec is temporary, just to avoid recreating a vector many times
{
  double diff = 0.;
  
  if (status == good) {
    
    likelihood = 0.;
    for (int i = 0 ; i != nclusters; i++) {
      tvec[i] = lambda[region][i]*my_t_pdf( contrast, nu[i], stdev[i], mean[i]);
      u[i] = (nu[i] + 1.)/(nu[i] + gsl_pow_2( (contrast - mean[i])/stdev[i] ));
      likelihood += tvec[i];     
    }
    
    //----------------- some fudge factor here
    if ( lambda[region][1] > 0.) {
      if (contrast > mean[1])   {tvec[0] = 0.;}
      if (contrast < mean[1])   {tvec[2] = 0.;}
    }
    
    double t = accumulate (tvec.begin(), tvec.end(), 0.);       
    for (int i = 0 ; i != nclusters; i++) {
      tvec[i] /= t; 
      if (forPerturb == false) {diff = max(diff, fabs(tvec[i]-f[i])); f[i] = tvec[i];}
      else {pert[i] += tvec[i];}
    }
  }

  return diff;
}




///---------------------------------
double DataPoint::Perturbate (const int allele1, const int allele2, const double sigma1, const double sigma2)    //modifies the contrast only, not the intensity
{
  double S1 = signal_ACGT[allele1] + gsl_ran_gaussian(r, sigma1), S2 = signal_ACGT[allele2] + gsl_ran_gaussian(r, sigma2);
  double S = S1 + S2;
  if (S == 0.)  {contrast = 0.;} 
  else {
    double y = (2*S2/S) - 1.; 
    if (fabs(y) <  1) {contrast = sinh(2*y)/sinh(2.);}
    if (fabs(y) >= 1) {contrast = y;}
  }   
}


double DataPoint::Get_signal (const int allele, const int what_call)
{
  if ((max_element(f.begin(), f.end()) - f.begin() == what_call) && (status == good))  {return (signal_ACGT[allele]);}
  return -99;
}


int Filter (vector<double> & data, double * dest) {   //filters a vector of data into a destination array called dest, while removing missing values denoted by -99
  int c = 0;
  for (int i = 0; i != (int) data.size(); i++) {if (data[i] != -99.) {dest[c] = data[i]; c++;}}
  return c;
}

void SNP::Perturbate () 
{
  double frac = 1.;
  vector<double> signal (data.size());
  double * datavec = new double [data.size()];

  int call1 = 0, all1 = 0;
  transform(data.begin(), data.end(), signal.begin(), boost::bind(&DataPoint::Get_signal, _1, all1, call1));   //data with call 0 and I want signal 0: puts the signal in the vector signal
  int l1 = Filter(signal, datavec);   //puts the data in the array datavec
  double sigma1 = frac*gsl_stats_sd(datavec, 1, l1);  //computes the standard dec

  int call2 = 0, all2 = 0;
  transform(data.begin(), data.end(), signal.begin(), boost::bind(&DataPoint::Get_signal, _1, all2, call2));   //data with call 2 and I want signal 1: puts the signal in the vector signal
  int l2 = Filter(signal, datavec);   //puts the data in the array datavec
  double sigma2 = frac*gsl_stats_sd(datavec, 1, l2);   //computes the std dev

  vector<double> tvec(nclusters);   //temporary vector
  for_each (data.begin(), data.end(), boost::bind(&DataPoint::Perturbate, _1, allele1, allele2, sigma1, sigma2));  //now perturbates each point separately: modifies only the 
  for_each (data.begin(), data.end(), boost::bind(&DataPoint::Expectation, _1, boost::ref(lambda), boost::ref(mean), boost::ref(stdev), boost::ref(nu), nclusters, boost::ref(tvec), true));   //now recompute the expectation: the true is because I want to use the perturbation version

  delete [] datavec;
}



void Perturbate (vector<SNP *> vs, const int nb_random)   {for (int i = 0; i != nb_random; i++) {for_each (vs.begin(), vs.end(), boost::bind(&SNP::Perturbate, _1));}} //perturbates each SNP




double SNP::Expectation () {      //return the max difference between the previous probabilities and the new ones
  vector<double> vdiff(data.size());
  vector<double> tvec(nclusters);
  transform(data.begin(), data.end(), vdiff.begin(), boost::bind(&DataPoint::Expectation, _1, boost::ref(lambda), boost::ref(mean), boost::ref(stdev), boost::ref(nu), nclusters, boost::ref(tvec), false));   //false because I am not doing a perturbation analysis here
  return *(max_element (vdiff.begin(), vdiff.end()));
}






void DataPoint::EstimateLambda (vector<vector<double> > & alpha, const double weight)  {if (status == good) {int nc = f.size(); for (int i = 0; i != nc; i++) {alpha[region][i] += weight*f[i];}}}


void Update_lambda(vector<SNP *> & vdata, const bool HWloc)
{
  if (vdata.empty()) {cerr<<"There is no data to look at\n"; exit(1);}
  int nregions = vdata[0]->nregionsf(), nclusters = vdata[0]->nclustersf(), nsets = vdata.size();
  bool X = vdata[0]->ChrX();

  vector<vector<double> >  alpha, alpha_men;
  vector<double> temp(nclusters, 0.); 
  for (int r = 0; r != nregions; r++) {alpha.push_back(temp);alpha_men.push_back(temp);}
  
  for (int i = 0; i != nsets; i++) {
    double weight = 1.; if ( (X == true) && (vdata[i]->Test_sex(male))  )  {weight = 0.5;}
    for_each(vdata[i]->data.begin(), vdata[i]->data.end(), boost::bind(&DataPoint::EstimateLambda, _1, boost::ref(alpha), weight));
  }


  for (int i = 0; i != nregions; i++) {        //-------------- now normalise the alpha to get lambda

    for (int j = 0; j != nclusters; j++) {if (alpha[i][j] < 1.5) {alpha[i][j] = 0.;}}
    double t = accumulate(alpha[i].begin(), alpha[i].end(), 0.); 

    if (t > 0) {
      if (HWloc == false) {
	for (int j = 0; j != nclusters; j++) {alpha[i][j] /= t;}
	for (int j = 0; j != nclusters; j++) {alpha_men[i][0] = alpha[i][0] + 0.5*alpha[i][1]; alpha_men[i][1] = 0.; alpha_men[i][2] = alpha[i][2] + 0.5*alpha[i][1];}	
      }      
      if (HWloc == true) {
      	double p = (alpha[i][0] + 0.5*alpha[i][1])/t;	
	alpha[i][0] = p*p; alpha[i][1] = 2.*p*(1.-p); alpha[i][2] = (1.- p)*(1.- p);
	alpha_men[i][0] = p; alpha_men[i][1] = 0.; alpha_men[i][2] = (1.- p);
      }
    }  else {alpha[i].assign(nclusters, -99);}
  }

  for (int i = 0; i != nsets; i++) {
    if ( (vdata[i]->Test_sex(male)) && X )  {vdata[i]->lambda = alpha_men;}    else {vdata[i]->lambda = alpha;}    //and input the new lambda in the old data
  }

}







double mypsi (const double x, const double t2) {return (-gsl_sf_psi(x/2.) + log(x/2.) + t2);}   //function useful for the Fixed_point routine below

double Fixed_point(const double t2) { //poorly written numerical function that would deserve to be rewritten and optimized at some point
  
  double down = 0.001, up = 30.;
  
  if (mypsi(up, t2) > 0) return up;
  if ( (mypsi(down, t2) < 0) || (mypsi(up, t2) > 0)) {cerr<<"Bad init points "<<down<<"\t"<<mypsi(down, t2)<<"\t"<<mypsi(up, t2)<<"\t"<<t2<<"\t"<<mypsi(0.0001, t2)<<endl;exit(1);}

  while (fabs(up - down) > 0.01) {
    double m = (up+down)/2.;
    double fm = mypsi(m, t2);
    
    if (fm < 0) up = m;
    if (fm >= 0) down = m;
  };
  
  return (up+down)/2.;
}


void DataPoint::Update_nu(vector<double> & values, const int cluster)  {if (status == good) {values[0] += f[cluster]*(log(u[cluster]) - u[cluster]); values[1] += f[cluster];}}

void SNP::Update_nu()
{
  for (int j = 0; j != nclusters; j++) {
    double t1 = (nu[j] + 1.)/2., n = 0., s = 0.;
    
    vector<double> s_n (2, 0);
    for_each (data.begin(), data.end(), boost::bind(&DataPoint::Update_nu, _1, boost::ref(s_n), j));
    
    if (s_n[1] > 0) {
      double t2 = s_n[0] / s_n[1] + 1 + gsl_sf_psi (t1) - log(t1); 
      if (t2 != t2) {cerr<<"t2 is messed up "<<t1<<"\t"<<s<<"\n"<<n<<endl;exit(1);}
      nu[j] = Fixed_point(t2);
    }  else {nu[j] = 3.;}
  }

}




void DataPoint::Update_sigma(vector<double> & values, const int cluster, const double mean)  {if (status == good) {values[0] += gsl_pow_2(contrast-mean)*f[cluster]*u[cluster]; values[1] += f[cluster];}}

void SNP::Update_sigma()
{
  for (int j = 0 ; j != nclusters; j++) {   //-------------------------------update on m, separately for each cluster
    vector<double> xz_z (2, 0.);
    for_each (data.begin(), data.end(), boost::bind(&DataPoint::Update_sigma, _1, boost::ref(xz_z), j, mean[j]));
    if ( xz_z [1] > 0 )    {stdev [ j ] = sqrt ( xz_z[0] / xz_z[1] );} else {stdev[j] = 0.1;}

    stdev[j] =  GSL_MAX(stdev[j], 0.01);      //--------------------------------- and now some common sense boundaries
    stdev[j] =  GSL_MIN(stdev[j], 0.5);
  }
}





void SNP::Apply_boundaries_mean()  //verify that the mean location of the cluster is within the specified boundaries
{
  for (int i = 0; i != nclusters; i++) {
    if (mean[i] > boundaries[i][1]) mean[i] = boundaries[i][1];
    if (mean[i] < boundaries[i][0]) mean[i] = boundaries[i][0];    
  }
}


void DataPoint::Update_mean(vector<double> & values, const int cluster)  {if (status == good) {values[0] += contrast*f[cluster]*u[cluster]; values[1] += f[cluster]*u[cluster];}}


void SNP::Update_mean()
{
  for (int j = 0 ; j != nclusters; j++) {   //-------------------------------update on m, separately for each cluster
    vector<double> xz_z (2, 0);
    for_each (data.begin(), data.end(), boost::bind(&DataPoint::Update_mean, _1, boost::ref(xz_z), j));
    if ( xz_z [1] > 0 )    {mean [ j ] = xz_z[0] / xz_z[1];} else {mean[j] = j-1;}
  }
}


double sumLike(double sumSoFar, const DataPoint & d) {return (sumSoFar + log(d.likelihood));}
double SNP::LogLikelihood() const  {return accumulate(data.begin(), data.end(), 0., sumLike);}


void EM_slave(vector<SNP *> & v)
{
  bool HWloc = true;
  int iter = 0;
  do {
    vector<double> vdiff (v.size());
    transform (v.begin(), v.end(), vdiff.begin(), boost::mem_fn(&SNP::Expectation));         //first estimate the a-posteriori frequencies
    double diff = *(max_element (vdiff.begin(), vdiff.end()));   //how much has it changed
    
    //double l = 0.; for (int j = 0; j != (int) v.size(); j++)    {l += v[j]->LogLikelihood();}   cout<<"Iter "<<iter<<": "<<l<<endl;
    
    if (iter > 3) {        //test the exit conditions only after at least three loops (quite arbitrary)
      if ( (diff < 0.001) && (HWloc == true) )  {HWloc = false; diff = 1.;}
      if (diff < 0.001) break;   //it it does not make a difference anymore then quite the loop
    }


    Update_lambda(v, HWloc);     //update the lambda
    for_each(v.begin(), v.end(), boost::mem_fn(&SNP::Update_mean));        //update the means
    for_each(v.begin(), v.end(), boost::mem_fn(&SNP::Apply_boundaries_mean));        //check the boundary conditions
    for_each(v.begin(), v.end(), boost::mem_fn(&SNP::Update_sigma));        //update the sigmas
    for_each(v.begin(), v.end(), boost::mem_fn(&SNP::Update_nu));        //update the nus
    
    iter++;
  }
  while (iter < 150);
}




void EM (vector<SNP *> & v, const vector<int> & initial_conditions)    //the actual EM algorithm
{

  double p_default = 0.9;
  vector<double> likelihoodArray (initial_conditions.size(), 0);

  for (int i = 0; i != (int) initial_conditions.size(); i++) {   //for each set of initial condition
    cout<<"\nStarting the EM algorithm at point "<<i<<endl;
    for_each(v.begin(), v.end(), boost::bind(&SNP::Init_parameters, _1, initial_conditions[i], p_default));  //places the initial conditions for each dataset
    EM_slave(v);    

    for (int j = 0; j != (int) v.size(); j++)    {likelihoodArray[i] += v[j]->LogLikelihood();}   
    cout<<"--- > logLikelihood for starting point "<<i<<" :"<<likelihoodArray[i]<<endl;
  }

  //------------- Now pick the best and re-estimate the best parameters
  int best = max_element (likelihoodArray.begin(), likelihoodArray.end()) - likelihoodArray.begin();
  for_each(v.begin(), v.end(), boost::bind(&SNP::Init_parameters, _1, initial_conditions[ best ], p_default));  //places the initial conditions for each dataset
  EM_slave(v);    

  
}
