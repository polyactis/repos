/* This file is used to try out functions for debugging, in main(),
just before replicate() is called. For example it could have the following 
lines in it:

printf("\n\tRate with time=0.5, theta=%.2lf, m=%.2lf is %.4e\n",
	theta,m,rate(t,0.5,theta,m));
exit(1);
*/
